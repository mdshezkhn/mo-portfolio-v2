**Candidate Name**
Educational Leader

About:
👉 Experienced international primary educator with a proven track record of delivering high-quality education in diverse, multicultural environments.

👉 Coached and mentored 100+ educators to improve instructional quality and engagement metrics.
👉 Led quality assurance initiatives across distributed teaching teams, ensuring consistent curriculum delivery.
👉 Spearheaded primary curriculum design and EAL integration for international classrooms.

Experience:
🔹 Primary Educator | Scholars Academy (2014-01 - 2016-11)
🔹 ESL Educator | Zhejiang University (2016-11 - 2017-08)
🔹 Early Years EAL Teacher | Eton House Kindergarten (2017-08 - 2018-06)
🔹 Primary Educator & Curriculum Lead | Aoxin International School (2018-07 - 2020-08)
🔹 Educator Development Lead | WhiteHat Jr (2020-08 - 2022-07)
🔹 Teacher Trainer & Quality Assurance | GEDU Global Education (2022-09 - 2023-08)
🔹 Primary Educator & Curriculum Lead | Aoxin International School (2024-02 - Present)
# Compiler Build Report
Generated at: 2026-07-31T17:51:04.260010

## Claim Utilization
| Metric | Value |
|---|---|
| Approved | 1 |
| Selected | 4 |
| Rendered | 4 |

## Selection Engine Decisions
- Claims Selected: 4
- Claims Rejected: 0

### Rejections Summary
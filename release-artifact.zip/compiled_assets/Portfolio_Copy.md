<!--
Asset:
Portfolio_Copy_v1.0

Built From

BS-1.0
CR-1.0
ER-1.0

Claims Used

C-003
C-004
C-005
C-006
C-007
C-008
C-009
C-010
C-011
C-012
C-013
C-014
C-017
C-019
C-020
C-023

Generated

2026-07-25

Compliance

PASS
-->

# Digital Portfolio

## Hero Section
## Mohammed Shehzad Khan
**International Primary Educator • EAL Specialist • Teacher Mentor • Curriculum Development**
*Available from August 2027*

> Helping multilingual primary learners access challenging curriculum through evidence-informed EAL practice.

## About Me

**Career Journey**
Classroom Educator → Teacher Development → Instructional Quality Leadership → International Primary EAL Education

Primary Educator and EAL Specialist with 11+ years of experience across international schools in China and India. I help multilingual learners develop the academic English needed to succeed across the primary curriculum through explicit language instruction integrated with inquiry-based learning. Experienced in supporting colleagues through mentoring, lesson modelling and collaborative planning.

My career journey began in foundational primary education and early immersion EAL, progressing into instructional quality leadership across international operations. I have since returned to international primary classrooms to apply these frameworks directly to multilingual cohorts, combining structured language development with data-informed instruction. <!-- CLAIM:C-017 -->

## Professional Evidence

*This portfolio is a curated selection of artifacts demonstrating my professional practice:*

* **Grade 5 Writing Moderation:** [Context] → [Your role] → [Artifact] → [Reflection]
* **Primary Literacy Action Research:** [Context] → [Your role] → [Artifact] → [Reflection]
* **EAL Curriculum Alignment:** [Context] → [Your role] → [Artifact] → [Reflection]
* **Instructional Quality Coaching:** [Context] → [Your role] → [Artifact] → [Reflection]

## Areas of Expertise
* **Instructional Quality:** Support educator development through coaching, lesson observations and instructional quality processes.
* **Curriculum Design:** Design and implement primary curriculum while collaborating on cross-curricular planning.
* **Assessment & Early Years:** Moderate writing assessments and support early-years language development through structured EAL practice.

## Education and Certifications
* **PGCE (University of Cumbria)** — My postgraduate action research explored evidence-informed strategies for improving literacy outcomes in multilingual primary classrooms, reinforcing my commitment to data-informed teaching.
* **B.Ed. (Bachelor of Education)**
* **M.A. English Language and Literature** — Harris University
* **B.Sc. Physics**
* **TESOL Certification**
* **TEFL Certification**

## Languages
* **English** — Fluent (professional working language)

# LinkedIn - Ready to Paste (Concrete Draft)

*Use this document to copy and paste text directly into your LinkedIn profile.*

---

## 1. Professional Headline

International Primary Educator • EAL Specialist • Teacher Mentor • Curriculum Development

---

## 2. About

Primary Educator and EAL Specialist with 11+ years of experience across international schools in China and India. I help multilingual learners develop the academic English needed to succeed across the primary curriculum through explicit language instruction integrated with inquiry-based learning. Experienced in supporting colleagues through mentoring, lesson modelling and collaborative planning.

My teaching combines structured language development, formative assessment and data-informed instruction to help multilingual learners build confidence and access challenging curriculum content. Alongside classroom teaching, I contribute through curriculum planning, assessment moderation and collaborative professional learning to support consistent instructional practice across primary teams.

---

## 3. Featured (To Pin to Profile)

1. **Digital Portfolio:** [Link to Digital Portfolio]
2. **Teaching Philosophy:** [Core principles of language and inquiry learning]
3. **PGCE Action Research:** [Summary of primary literacy action research]
4. **Classroom Artifact:** [Placeholder: Anonymized curriculum document or lesson plan]

---

## 4. Experience

### Aoxin International School
**Title:** Primary EAL Teacher
**Dates:** Feb 2024 – Present
**Description:**
* Deliver English and cross-curricular instruction for primary learners in a bilingual international school.
* Design differentiated lessons for multilingual learners across varying English proficiency levels.
* Moderate Grade 5 writing assessments.
* Collaborate with Chinese and international teachers on curriculum planning.
* Support colleagues through lesson modelling and language-support strategies.
* Use formative assessment to monitor pupil progress.

### Aoxin International School
**Title:** EAL / English Teacher
**Dates:** Jul 2018 – Aug 2020
**Description:**
* Delivered subject-based language support across primary grades.
* Moderated Grade 5 writing assessments and supported new teachers in instructional delivery.

### GEDU Global Education
**Title:** Training & Quality Lead
**Dates:** Sep 2022 – Aug 2023
**Description:**
* Designed teacher training programmes.
* Conducted lesson observations.
* Led instructional quality reviews.
* Supported educator development.
* Collaborated with cross-functional teams supporting educator quality across international operations.

### WhiteHat Jr / BYJU'S
**Title:** Educator Development Lead
**Dates:** Aug 2020 – Jul 2022
**Description:**
* Analyzed instructional performance data to identify professional development needs.
* Mentored a cohort of educators to improve lesson delivery and instructional practice.
* Designed and delivered targeted coaching interventions.
* Tracked continuous educator development through data dashboards.

### Eton House Kindergarten
**Title:** Early Years EAL Teacher & Teacher Mentor
**Dates:** Aug 2017 – Jun 2018
**Description:**
* Delivered early-years EAL instruction using play-based and structured phonics methods.
* Supported English language acquisition for pre-school learners.
* Modelled language teaching strategies for classroom colleagues.

### Zhejiang University / Helen China TEFL Network
**Title:** ESL Instructor
**Dates:** Nov 2016 – Aug 2017
**Description:**
* Delivered communicative English instruction to middle and high school learners.
* Designed engaging lesson plans focused on spoken fluency and listening comprehension.
* Assessed student progress and provided regular feedback on language development.

### Scholars Academy
**Title:** Primary Educator & EAL Teacher
**Dates:** Jan 2014 – Nov 2016
**Description:**
* Taught foundational primary subjects including English, Science, and Mathematics.
* Developed cross-curricular lesson materials for diverse learning needs.
* Managed classroom routines and maintained a supportive learning environment.

---

## 5. Education

### University of Cumbria
**Degree:** PGCE (Postgraduate Certificate in Education)
**Dates:** Sep 2025 – Jul 2026
**Description:** Action research examining evidence-informed strategies for improving primary literacy outcomes in multilingual classrooms.

### University of Kashmir
**Degree:** B.Ed., Teacher Education
**Dates:** Oct 2021 – Mar 2024

### Harris University
**Degree:** M.A., English Language and Literature
**Dates:** 2007 – 2009

### University of Mumbai
**Degree:** B.Sc., Physics
**Dates:** 2004 – 2007

---

## 6. Licenses & Certifications
* **TESOL Certification**
* **TEFL Certification**

---

## 7. Skills (Tags)
* Primary Education
* English as an Additional Language (EAL)
* Curriculum Development
* Assessment
* Teacher Training
* Literacy
* Differentiated Instruction
* ESL
* Phonics
* Classroom Management
* Lesson Planning
* Educational Leadership
* Student Assessment
* Inquiry-Based Learning
* STEM Education
* English Language Teaching
* Coaching
* Educational Technology
* Professional Development
* International Education

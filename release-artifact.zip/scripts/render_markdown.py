import json
from pathlib import Path
import argparse

def render_cv(view_model):
    lines = []
    lines.append(f"# {view_model['candidate']['name']}")
    lines.append(f"## {view_model['candidate']['title']}\n")
    
    if view_model['executive_summary']:
        lines.append("### Executive Summary")
        for statement in view_model['executive_summary']:
            lines.append(f"- {statement}")
        lines.append("")
        
    lines.append("### Professional Experience")
    for exp in view_model['experience']:
        lines.append(f"#### {exp['title']} at {exp['organization']}")
        lines.append(f"*{exp['start_date']} - {exp['end_date']}*")
        for hl in exp['highlights']:
            lines.append(f"- {hl}")
        lines.append("")
        
    lines.append("### Education")
    for ed in view_model['education']:
        year_str = f" ({ed['year']})" if ed['year'] else ""
        lines.append(f"- **{ed['name']}**, {ed['institution']}{year_str}")
        
    return "\n".join(lines)

def render_linkedin(view_model):
    lines = []
    lines.append(f"**{view_model['candidate']['name']}**")
    lines.append(f"{view_model['candidate']['title']}\n")
    
    lines.append("About:")
    for statement in view_model['executive_summary']:
        lines.append(f"👉 {statement}")
    lines.append("")
    
    lines.append("Experience:")
    for exp in view_model['experience']:
        lines.append(f"🔹 {exp['title']} | {exp['organization']} ({exp['start_date']} - {exp['end_date']})")
        
    return "\n".join(lines)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Markdown Renderer")
    parser.add_argument("--vm-file", default="artifacts/professional_profile_vm.json")
    args = parser.parse_args()
    
    vm_path = Path(args.vm_file)
    if not vm_path.exists():
        print(f"View model not found at {vm_path}")
        exit(1)
        
    with open(vm_path, "r", encoding="utf-8") as f:
        view_model = json.load(f)
        
    # Ensure generated directory exists for unapproved outputs
    generated_dir = Path("artifacts/generated")
    generated_dir.mkdir(parents=True, exist_ok=True)
    
    cv_md = render_cv(view_model)
    with open(generated_dir / "cv.md", "w", encoding="utf-8") as f:
        f.write(cv_md)
        
    linkedin_md = render_linkedin(view_model)
    with open(generated_dir / "linkedin.md", "w", encoding="utf-8") as f:
        f.write(linkedin_md)
        
    print(f"Generated Markdown artifacts in {generated_dir}")

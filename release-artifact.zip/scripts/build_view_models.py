import json
import argparse
from pathlib import Path

def build_professional_profile(graph, market="british"):
    from selection_engine import select_claims
    
    # Get selected claims
    selected_claims, decision_log = select_claims(graph, market=market, min_confidence="supported")
    
    # Get employments (sorted chronologically descending)
    employments = list(graph.employments())
    employments = sorted(employments, key=lambda e: e.get('start_date', ''), reverse=True)
    
    # Get education/qualifications
    qualifications = list(graph.qualifications())
    
    # Build view model
    view_model = {
        "candidate": {
            "name": "Candidate Name", # Placeholder, ideally from a Person entity
            "title": "Educational Leader"
        },
        "executive_summary": [c.get('statement') for c in selected_claims if c.get('priority') == 'high'],
        "key_claims": [c.get('statement') for c in selected_claims],
        "experience": [],
        "education": []
    }
    
    for emp in employments:
        emp_id = emp['id']
        emp_claims = []
        for c in selected_claims:
            for edge in graph.edges:
                if edge.get('type') == 'SUPPORTED_BY' and edge.get('from') == c['id'] and edge.get('to') == emp_id:
                    emp_claims.append(c.get('statement'))
        
        # Resolve Organization
        org_name = "Unknown Org"
        for edge in graph.edges:
            if edge.get('type') == 'WORKED_AT' and edge.get('from') == emp_id:
                org_id = edge.get('to')
                org_entity = graph.entities_by_id.get(org_id)
                if org_entity:
                    org_name = org_entity.get('canonical_name', org_name)
                    
        # Resolve Role
        role_name = "Unknown Role"
        for edge in graph.edges:
            if edge.get('type') == 'HAS_ROLE' and edge.get('from') == emp_id:
                role_id = edge.get('to')
                role_entity = graph.entities_by_id.get(role_id)
                if role_entity:
                    role_name = role_entity.get('title', role_name)
                    
        # Parse Dates
        dates_block = emp.get('dates', {})
        start_date = dates_block.get('start', {}).get('date', 'Unknown Start')
        end_date = dates_block.get('end', {}).get('date')
        if not end_date:
            if dates_block.get('end', {}).get('present'):
                end_date = 'Present'
            else:
                end_date = 'Unknown End'
                    
        view_model["experience"].append({
            "id": emp_id,
            "title": role_name,
            "organization": org_name,
            "start_date": start_date,
            "end_date": end_date,
            "highlights": emp_claims
        })
        
    for qual in qualifications:
        qual_id = qual['id']
        degree = qual.get('degree', 'Unknown Qualification')
        
        # Resolve Institution
        inst_name = "Unknown Institution"
        for edge in graph.edges:
            if edge.get('type') == 'STUDIED_AT' and edge.get('from') == qual_id:
                inst_id = edge.get('to')
                inst_entity = graph.entities_by_id.get(inst_id)
                if inst_entity:
                    inst_name = inst_entity.get('canonical_name', inst_name)
                    
        # Parse Year
        dates_block = qual.get('dates', {})
        end_date = dates_block.get('end', {}).get('date')
        if end_date == 'UNKNOWN':
            end_date = None
            
        if not end_date:
            if dates_block.get('end', {}).get('present'):
                end_date = 'Present'
            else:
                end_date = None
        year = end_date
        
        view_model["education"].append({
            "id": qual_id,
            "name": degree,
            "institution": inst_name,
            "year": year
        })
        
    return view_model

if __name__ == "__main__":
    import sys
    # Add parent dir to path for imports
    sys.path.append(str(Path(__file__).parent))
    from query_engine import load_graph
    
    parser = argparse.ArgumentParser(description="Build View Models")
    parser.add_argument("--data-dir", default="career-data")
    parser.add_argument("--market", default="british")
    args = parser.parse_args()
    
    graph = load_graph(args.data_dir)
    view_model = build_professional_profile(graph, market=args.market)
    
    artifacts_dir = Path("artifacts")
    artifacts_dir.mkdir(exist_ok=True)
    
    output_path = artifacts_dir / "professional_profile_vm.json"
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(view_model, f, indent=2)
        
    print(f"Generated View Model at {output_path}")

import subprocess
import time
import sys

STAGES = [
    {"name": "Audit Claims", "cmd": ["python", "scripts/audit_claims.py"], "max_ms": 1000},
    {"name": "Validate ID Registry", "cmd": ["python", "scripts/validate_ids.py"], "max_ms": 200},
    {"name": "Validate Employment YAML", "cmd": ["python", "scripts/validate_yaml.py", "--file", "career-data/facts/employment.yml"], "max_ms": 200},
    {"name": "Validate Education YAML", "cmd": ["python", "scripts/validate_yaml.py", "--file", "career-data/facts/education.yml"], "max_ms": 200},
    {"name": "Resolve Graph", "cmd": ["python", "scripts/resolve_graph.py"], "max_ms": 200},
    {"name": "Validate Semantics", "cmd": ["python", "scripts/validate_semantics.py"], "max_ms": 200},
    {"name": "Metrics Engine", "cmd": ["python", "scripts/metrics_engine.py"], "max_ms": 150},
    {"name": "Content Quality Engine", "cmd": ["python", "scripts/content_quality_engine.py"], "max_ms": 200},
    {"name": "Claim Selection Engine", "cmd": ["python", "scripts/selection_engine.py", "--market", "british"], "max_ms": 150},
    {"name": "Compile Claim Register", "cmd": ["python", "scripts/compile_claim_register.py"], "max_ms": 300},
    {"name": "Compile Intermediate", "cmd": ["python", "scripts/compile_intermediate.py"], "max_ms": 300},
    {"name": "Policy Engine", "cmd": ["python", "scripts/policy_engine.py"], "max_ms": 200},
    {"name": "Build View Models", "cmd": ["python", "scripts/build_view_models.py"], "max_ms": 400},
    {"name": "Render Markdown", "cmd": ["python", "scripts/render_markdown.py"], "max_ms": 400},
    {"name": "Cross-Artifact Verification", "cmd": ["python", "scripts/verify_cross_artifact.py"], "max_ms": 400},
    {"name": "Compiler Report", "cmd": ["python", "scripts/build_compiler_report.py"], "max_ms": 400},
    {"name": "Architecture Rules Test", "cmd": ["python", "-m", "pytest", "tests/test_architecture_rules.py", "-q"], "max_ms": 1000},
    {"name": "Snapshot Regression Tests", "cmd": ["python", "-m", "pytest", "tests/test_snapshot_regression.py", "-q"], "max_ms": 1000}
]

def run_pipeline():
    print("====================================")
    print(" Starting CI/CD Pipeline Validation ")
    print("====================================\n")
    
    total_start = time.time()
    
    for stage in STAGES:
        print(f"Running: {stage['name']}...")
        start_t = time.time()
        
        try:
            import os
            env = os.environ.copy()
            env['PYTHONIOENCODING'] = 'utf-8'
            result = subprocess.run(stage["cmd"], capture_output=True, text=True, encoding="utf-8", env=env)
            elapsed_ms = (time.time() - start_t) * 1000
            
            if result.returncode != 0:
                print(f"[FAIL] {stage['name']} failed in {elapsed_ms:.0f} ms (Exit Code {result.returncode})")
                print("--- STDOUT ---")
                print(result.stdout)
                print("--- STDERR ---")
                print(result.stderr)
                sys.exit(1)
                
            status = "PASS"
            if elapsed_ms > stage["max_ms"]:
                status = f"WARN (Exceeded {stage['max_ms']}ms gate)"
                
            print(f"[{status}] {stage['name']} completed in {elapsed_ms:.0f} ms\n")
            
        except Exception as e:
            print(f"[ERROR] Failed to run {stage['name']}: {e}")
            sys.exit(1)
            
    total_elapsed = time.time() - total_start
    print("====================================")
    print(f" CI/CD Pipeline PASSED in {total_elapsed:.2f} s ")
    print("====================================")
    
if __name__ == "__main__":
    run_pipeline()

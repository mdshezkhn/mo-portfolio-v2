import json
import os
from pathlib import Path

# Base schema that all generated schemas must extend
BASE_TEMPLATE = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {},
    "required": []
}

# ISO-8601 structured dates
DATE_SCHEMA = {
    "type": "object",
    "properties": {
        "start": {
            "type": "object",
            "properties": {
                "date": {"type": "string", "pattern": "^([0-9]{4}(-[0-9]{2})?|UNKNOWN)$"}
            },
            "required": ["date"]
        },
        "end": {
            "type": "object",
            "properties": {
                "date": {"type": ["string", "null"], "pattern": "^([0-9]{4}(-[0-9]{2})?|UNKNOWN)$"},
                "present": {"type": "boolean"}
            }
        }
    },
    "required": ["start"]
}

# Orthogonal confidence and review status
CONFIDENCE_ENUM = ["verified", "supported", "plausible", "asserted"]
REVIEW_STATUS_ENUM = ["approved", "pending", "conflict", "obsolete"]

# The definitions of specific schemas
SCHEMA_DEFINITIONS = {
    "facts/identity": {
        "properties": {
            "id": {"type": "string", "pattern": "^EMP-[0-9]{4}$"},
            "name": {"type": "string"},
            "title": {"type": "string"}
        },
        "required": ["id", "name"]
    },
    "facts/education": {
        "properties": {
            "education_records": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string", "pattern": "^EDU-[0-9]{4}$"},
                        "degree": {"type": "string"},
                        "institution_id": {"type": "string", "pattern": "^INST-[0-9]{4}$"},
                        "institution": {"type": "string"},
                        "dates": DATE_SCHEMA,
                        "confidence": {"type": "string", "enum": CONFIDENCE_ENUM},
                        "review_status": {"type": "string", "enum": REVIEW_STATUS_ENUM},
                        "primary_evidence_id": {"type": "string", "pattern": "^(E-[0-9]{4}|N/A)$"},
                        "institution_recognition_status": {"type": "string"},
                        "publication": {
                            "type": "object",
                            "properties": {
                                "public_cv": {"type": "boolean"},
                                "linkedin": {"type": "boolean"},
                                "recruiter_pack": {"type": "string"},
                                "premium_schools": {"type": "boolean"},
                                "notes": {"type": "string"}
                            },
                            "required": ["public_cv", "linkedin"]
                        }
                    },
                    "required": ["id", "degree", "institution_id", "institution", "dates", "confidence", "review_status", "primary_evidence_id", "publication"]
                }
            }
        },
        "required": ["education_records"]
    },
    "facts/employment": {
        "properties": {
            "employment_records": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string", "pattern": "^EMP-[0-9]{4}$"},
                        "employer_id": {"type": "string", "pattern": "^ORG-[0-9]{4}$"},
                        "role_id": {"type": "string", "pattern": "^ROLE-[0-9]{4}$"},
                        "employer": {"type": "string"},
                        "dates": DATE_SCHEMA,
                        "location": {"type": "string"},
                        "confidence": {"type": "string", "enum": CONFIDENCE_ENUM},
                        "review_status": {"type": "string", "enum": REVIEW_STATUS_ENUM},
                        "primary_evidence_id": {"type": "string", "pattern": "^(E-[0-9]{4}|N/A)$"}
                    },
                    "required": ["id", "employer_id", "role_id", "employer", "dates", "location", "confidence", "review_status", "primary_evidence_id"]
                }
            }
        },
        "required": ["employment_records"]
    },
    "facts/roles": {
        "properties": {
            "roles": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string", "pattern": "^ROLE-[0-9]{4}$"},
                        "title": {"type": "string"},
                        "description": {"type": "string"}
                    },
                    "required": ["id", "title"]
                }
            }
        },
        "required": ["roles"]
    },
    "facts/institutions": {
        "properties": {
            "institutions": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string", "pattern": "^INST-[0-9]{4}$"},
                        "canonical_name": {"type": "string"},
                        "aliases": {"type": "array", "items": {"type": "string"}}
                    },
                    "required": ["id", "canonical_name"]
                }
            }
        },
        "required": ["institutions"]
    },
    "facts/organisations": {
        "properties": {
            "organisations": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string", "pattern": "^ORG-[0-9]{4}$"},
                        "canonical_name": {"type": "string"},
                        "aliases": {"type": "array", "items": {"type": "string"}}
                    },
                    "required": ["id", "canonical_name"]
                }
            }
        },
        "required": ["organisations"]
    },
    "facts/evidence_links": {
        "properties": {
            "evidence_links": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "fact_id": {"type": "string", "pattern": "^(EMP|EDU|CERT|ORG|INST)-[0-9]{4}$"},
                        "evidence_ids": {
                            "type": "array",
                            "items": {"type": "string", "pattern": "^E-[0-9]{4}$"}
                        }
                    },
                    "required": ["fact_id", "evidence_ids"]
                }
            }
        },
        "required": ["evidence_links"]
    },
    "narratives/teaching_philosophy": {
        "properties": {
            "teaching_philosophy": {
                "type": "object",
                "properties": {
                    "confidence": {"type": "string", "enum": CONFIDENCE_ENUM},
                    "review_status": {"type": "string", "enum": REVIEW_STATUS_ENUM},
                    "authored_by": {"type": "string", "const": "Mohammed Shehzad Khan"},
                    "content": {"type": "string"}
                },
                "required": ["confidence", "review_status", "authored_by", "content"]
            }
        },
        "required": ["teaching_philosophy"]
    },
    "narratives/voice": {
        "properties": {
            "voice": {
                "type": "object",
                "properties": {
                    "tone": {"type": "array", "items": {"type": "string"}},
                    "reading_level": {"type": "string"},
                    "avoid": {"type": "array", "items": {"type": "string"}},
                    "prefer": {"type": "array", "items": {"type": "string"}}
                },
                "required": ["tone", "reading_level", "avoid", "prefer"]
            }
        },
        "required": ["voice"]
    },
    "facts/claims": {
        "properties": {
            "claims": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string", "pattern": "^CLAIM-[0-9]{4}$"},
                        "type": {"type": "string"},
                        "risk": {"type": "string"},
                        "visibility": {"type": "array", "items": {"type": "string"}},
                        "audiences": {"type": "array", "items": {"type": "string"}},
                        "dependencies": {"type": "array", "items": {"type": "string"}},
                        "status": {"type": "string"}
                    },
                    "required": ["id", "type", "visibility", "audiences", "status"]
                }
            }
        },
        "required": ["claims"]
    },
    "facts/relationships": {
        "properties": {
            "relationships": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string", "pattern": "^REL-[0-9]{4}$"},
                        "source_type": {"type": "string"},
                        "source_id": {"type": "string"},
                        "target_type": {"type": "string"},
                        "target_id": {"type": "string"},
                        "relationship": {"type": "string"}
                    },
                    "required": ["id", "source_type", "source_id", "target_type", "target_id", "relationship"]
                }
            }
        },
        "required": ["relationships"]
    },
    "facts/metrics": {
        "properties": {
            "metrics": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string", "pattern": "^METRIC-[0-9]{4}$"},
                        "name": {"type": "string"},
                        "type": {"type": "string", "enum": ["calculated", "static"]},
                        "source": {"type": "string"},
                        "value": {"type": ["number", "string"]}
                    },
                    "required": ["id", "name", "type"]
                }
            }
        },
        "required": ["metrics"]
    },
    "taxonomies/competency_taxonomy": {
        "properties": {
            "domains": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string", "pattern": "^DOM-[0-9]{4}$"},
                        "name": {"type": "string"},
                        "subdomains": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "id": {"type": "string", "pattern": "^SUB-[0-9]{4}$"},
                                    "name": {"type": "string"}
                                },
                                "required": ["id", "name"]
                            }
                        }
                    },
                    "required": ["id", "name"]
                }
            }
        },
        "required": ["domains"]
    },
    "facts/competencies": {
        "properties": {
            "competencies": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string", "pattern": "^COMP-[0-9]{4}$"},
                        "domain_id": {"type": "string", "pattern": "^DOM-[0-9]{4}$"},
                        "subdomain_id": {"type": "string", "pattern": "^SUB-[0-9]{4}$"},
                        "name": {"type": "string"},
                        "proficiency": {"type": "string"},
                        "evidence_ids": {"type": "array", "items": {"type": "string", "pattern": "^E-[0-9]{4}$"}},
                        "claim_ids": {"type": "array", "items": {"type": "string", "pattern": "^CLAIM-[0-9]{4}$"}},
                        "contexts": {"type": "array", "items": {"type": "string"}}
                    },
                    "required": ["id", "domain_id", "name", "proficiency"]
                }
            }
        },
        "required": ["competencies"]
    }
}

def generate_schemas(output_dir):
    out_path = Path(output_dir)
    # Ensure directories exist
    (out_path / "facts").mkdir(parents=True, exist_ok=True)
    (out_path / "narratives").mkdir(parents=True, exist_ok=True)
    (out_path / "reference").mkdir(parents=True, exist_ok=True)

    for schema_name, specific_schema in SCHEMA_DEFINITIONS.items():
        # Merge BASE_TEMPLATE with specific_schema
        merged = {
            "$schema": BASE_TEMPLATE["$schema"],
            "type": BASE_TEMPLATE["type"],
            "properties": {**BASE_TEMPLATE["properties"], **specific_schema.get("properties", {})},
            "required": BASE_TEMPLATE["required"] + specific_schema.get("required", [])
        }
        
        file_path = out_path / f"{schema_name}.schema.json"
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(merged, f, indent=2)
            
        print(f"Generated {file_path}")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Generate JSON Schemas for the Career OS")
    parser.add_argument("--output-dir", default="schemas", help="Directory to output generated schemas")
    args = parser.parse_args()
    
    generate_schemas(args.output_dir)
